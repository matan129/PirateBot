﻿namespace Britbot.Simulator
{
    /// <summary>
    /// This class should be able to simulate possible outcomes from
    /// assignment possibilities
    /// </summary>
    class Simulator
    {}
}
