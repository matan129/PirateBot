﻿namespace Britbot
{
    public enum GroupRole
    {
        Destroyer,
        Conquerer,
        Bait
    }
}