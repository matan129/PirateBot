﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pirates;

namespace WeekOneBot
{
    class EnemyFleet
    {
        private List<EnemyPirate> enemies;
    }
}
